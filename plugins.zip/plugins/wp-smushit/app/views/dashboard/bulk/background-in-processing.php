<div class="sui-notice sui-notice-info">
    <div class="sui-notice-content">
        <div class="sui-notice-message">
            <span class="sui-notice-icon sui-icon-info sui-md" aria-hidden="true"></span>
            <p>
            <?php
                esc_html_e( 'Bulk smush is running in the background.', 'wp-smushit' );
            ?>
            </p>
        </div>
    </div>
</div>